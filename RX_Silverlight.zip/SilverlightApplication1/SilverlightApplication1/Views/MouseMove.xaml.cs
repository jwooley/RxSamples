﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;

namespace SilverlightApplication1.Views
{
    public partial class MouseMove : Page
    {
        public MouseMove()
        {
            InitializeComponent();
        }

        // Executes when the user navigates to this page.
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            
            var mouseDown = from evt in Observable.FromEvent<MouseButtonEventArgs>(image, "MouseLeftButtonDown")
                            select evt.EventArgs.GetPosition(image);
            var mouseUp = Observable.FromEvent<MouseButtonEventArgs>(image, "MouseLeftButtonUp");
            var mouseMove = Observable.FromEvent<MouseEventArgs>(image, "MouseMove")
                .Select(evt => evt.EventArgs.GetPosition(this));

            var q = from imageOffset in mouseDown
                    from pos in mouseMove.TakeUntil(mouseUp)
                    select new
                    {
                        X = pos.X - imageOffset.X,
                        Y = pos.Y - imageOffset.Y
                    };

            q.Subscribe(value =>
                {
                    Canvas.SetLeft(image, value.X);
                    Canvas.SetTop(image, value.Y);
                });
        }

    }
}
