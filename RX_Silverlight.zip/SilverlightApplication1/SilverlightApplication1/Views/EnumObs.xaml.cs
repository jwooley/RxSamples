﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;
using System.Threading;
using System.Collections.ObjectModel;
using SilverlightApplication1.Observables;

namespace SilverlightApplication1.Views
{
    public partial class EnumObs : Page
    {
        public EnumObs()
        {
            InitializeComponent();
        }

        // Executes when the user navigates to this page.
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        private void Enumerable_Click(object sender, RoutedEventArgs e)
        {
            Stopwatch sw = new Stopwatch();

            sw.Start();
            var query = Enumerable.Range(1, 10)
                .Where(num => num % 2 == 0)
                .Do(num => Thread.SpinWait((10 - num) * 1000000))
                .ToList();

            sw.Stop();

            Results.ItemsSource = query;
            TotalTime.Text = "Total Time: " + sw.ElapsedTicks.ToString("n");
        }
        private void Observable_Click(object sender, RoutedEventArgs e)
        {
            Stopwatch sw = new Stopwatch();

            var list = new ObserverCollection<int>();

            sw.Start();
            var query = Enumerable.Range(1, 10).ToObservable()
                .Where(n => n % 2 == 0)
                .Do(n => Thread.SpinWait((10 - n) * 1000000));
            query.Subscribe(list);

            sw.Stop();
           
            Results.ItemsSource = list;
            TotalTime.Text = "Total Time: " + sw.ElapsedTicks.ToString("n");
        }
    }
}
