﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SilverlightApplication1
{
    public class SensorInfo
    {
        public string SensorType { get; set; }
        public DateTime TimeStamp { get; set; }
        public double SensorValue { get; set; }
    }
}
