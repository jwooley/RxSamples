﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Microsoft.Devices.Sensors;
using Microsoft.Xna.Framework;
using System.Threading;
using Microsoft.Phone.Reactive;

namespace WP7AccelerometerSample
{
    /// <summary>
    /// Sample adapted from MSDN Documentation at 
    /// http://msdn.microsoft.com/en-us/library/ff637521(v=VS.92).aspx
    /// </summary>
    public partial class MainPage : PhoneApplicationPage
    {

        Accelerometer accelerometer;
        bool useEmulation = true;

        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (!useEmulation)
            {
                accelerometer = new Accelerometer();
                IObservable<IEvent<AccelerometerReadingEventArgs>> accelerometerReadingAsObservable =
                     Observable.FromEvent<AccelerometerReadingEventArgs>(
                         ev => accelerometer.ReadingChanged += ev,
                         ev => accelerometer.ReadingChanged -= ev);

                var vector3FromAccelerometerEventArgs = from args in accelerometerReadingAsObservable
                                                        select new Vector3(
                                                            (float)args.EventArgs.X,
                                                            (float)args.EventArgs.Y,
                                                            (float)args.EventArgs.Z);

                vector3FromAccelerometerEventArgs.Subscribe(args => InvokeAccelerometerReadingChanged(args));

                try
                {
                    accelerometer.Start();
                }
                catch (Exception)
                {
                    ReadingTextBlock.Text = "error starting accelerometer";
                }
            }
            else
            {
                StartAccelerometerEmulation();
            }
        }

        IDisposable subscribed;
        private void StartAccelerometerEmulation()
        {
            if (subscribed == null)
            {
                var emulationObservable = GetEmulator();
                subscribed = emulationObservable.SubscribeOn(Scheduler.ThreadPool)
                    .Subscribe(AccelerometerReadingEventArgs => 
                        InvokeAccelerometerReadingChanged(AccelerometerReadingEventArgs));
            }
            else
            {
                subscribed.Dispose();
                subscribed = null;
            }
        }
        void InvokeAccelerometerReadingChanged(Vector3 data)
        {
            Deployment.Current.Dispatcher.BeginInvoke(() => AccelerometerReadingChanged(data));
        }
        void AccelerometerReadingChanged(Vector3 data)
        {
           ReadingTextBlock.Text =
                " x: " + data.X.ToString("0.00") +
                " y: " + data.Y.ToString("0.00") +
                " z: " + data.Z.ToString("0.00");

           Single multiplier;
           if (Single.TryParse(this.MoveMultiplier.Text,out multiplier))
           {
               ButtonTransform.X = data.X * multiplier;
               ButtonTransform.Y = data.Y * multiplier;
           }
        }
        public static IObservable<Vector3> GetEmulator()
        {
            var obs = Observable.Create<Vector3>(subscriber =>
            {
                Random rnd = new Random();
                for (double theta = 0; ; theta += .1)
                {
                    Vector3 reading = new Vector3(
                        (float)Math.Sin(theta),
                        (float)Math.Cos(theta * 1.1),
                        (float)Math.Sin(theta * .7));
                    reading.Normalize();

                    if (rnd.NextDouble() > .95)
                    {
                        reading = new Vector3(
                            (float)(rnd.NextDouble() * 3.0 - 1.5),
                            (float)(rnd.NextDouble() * 3.0 - 1.5),
                            (float)(rnd.NextDouble() * 3.0 - 1.5));
                    }
                    // return the vector and sleep before repeating
                    Thread.Sleep(100);
                    subscriber.OnNext(reading);
                }
            });
            return obs;
        }
    }
}
