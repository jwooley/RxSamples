﻿Imports Microsoft.VisualBasic
Imports SignalR.Hubs

Public Class ObservableSensorHub
    Inherits Hub

End Class
