﻿using System;

namespace WpfSharp
{
    public class SensorData
    {
        public DateTime Time { get; set; }
        public string Category { get; set; }
        public Double Value { get; set; }
    }
}