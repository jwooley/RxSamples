﻿
Partial Class Chat
    Inherits System.Web.UI.Page

End Class
