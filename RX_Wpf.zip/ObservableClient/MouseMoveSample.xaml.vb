﻿Class MouseMoveSample

    Private Sub MouseMoveSample_Initialized(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Initialized
        'Dim helloWorld = Observable.Return("Hello, World!")
        'helloWorld.Subscribe(Sub(value) TopText.Text = value)

        Dim timer = Observable.Interval(TimeSpan.FromSeconds(1)).ObserveOnDispatcher
        timer.Subscribe(Sub(value) TopText.Text = value.ToString())

        Dim mouseDown = From evt In Observable.FromEvent(Of MouseButtonEventArgs)(image, "MouseDown")
                        Select evt.EventArgs.GetPosition(image)

        Dim mouseUp = Observable.FromEvent(Of MouseButtonEventArgs)(image, "MouseUp")
        Dim mouseMove = From evt In Observable.FromEvent(Of MouseEventArgs)(image, "MouseMove")
                        Select evt.EventArgs.GetPosition(Me)

        Dim q = From imageOffset In mouseDown
                From pos In mouseMove.TakeUntil(mouseUp)
                Select X = pos.X - imageOffset.X,
                    Y = pos.Y - imageOffset.Y

        q.Subscribe(Sub(value)
                        Canvas.SetLeft(image, value.X)
                        Canvas.SetTop(image, value.Y)
                    End Sub)

    End Sub
End Class
