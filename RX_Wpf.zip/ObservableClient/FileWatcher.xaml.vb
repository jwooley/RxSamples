﻿Imports System.IO
Imports System.Linq

Public Class FileWatcher

    Private Sub FileWatcher_Initialized(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Initialized
        Dim createWatcher As New FileSystemWatcher With {.Path = "C:\Temp", .EnableRaisingEvents = True}
     
        Dim AllEvents = Observable.FromEvent(Of FileSystemEventArgs)(createWatcher, "Created").
            Merge(Observable.FromEvent(Of FileSystemEventArgs)(createWatcher, "Changed")).
            Merge(Observable.FromEvent(Of FileSystemEventArgs)(createWatcher, "Deleted")).
            ObserveOnDispatcher.Do(Sub(fsArgs) RefreshFileList())

        AllEvents.Subscribe()

        RefreshFileList()

    End Sub

    Private Sub RefreshFileList()
        Dim files = From file In New DirectoryInfo("C:\temp").GetFiles
                    Order By file.LastWriteTime Descending
                    Select file.Name

        FileList.ItemsSource = files
    End Sub

End Class
