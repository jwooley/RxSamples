﻿Imports Sensor
Imports System.ComponentModel

Class MainWindow

    Private Sensor As New ObservableSensor

    Private Sub Start_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles Start.Click
        Dim worker As New BackgroundWorker
        AddHandler worker.DoWork, Sub(s As Object, ars As DoWorkEventArgs)
                                      Sensor.StartSensor()
                                  End Sub
        worker.RunWorkerAsync(Sensor)
    End Sub

    Private Sub Stop_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles [Stop].Click
        Sensor.StopSensor()
    End Sub

    Private ActiveLowValueSensors As IDisposable

    Private Sub FilterLowValue_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles FilterLowValue.Click
        If ActiveLowValueSensors Is Nothing Then
            Dim lowValueSensors = From s In Sensor
                                  Where s.SensorValue < 3
                                  Select s.SensorValue

            ActiveLowValueSensors = lowValueSensors.Subscribe(New ConsoleObserver(Of Double)(ConsoleColor.Red))
        Else
            ActiveLowValueSensors.Dispose()
            ActiveLowValueSensors = Nothing
        End If

    End Sub

    Private Sub FilterFirstType_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles FilterFirstType.Click
        Dim TypeSensors = From s In Sensor
                       Where s.SensorType = "4"
                       Select s

        Dim listSource As New ObserverCollection(Of SensorInfo)
        FilteredList.ItemsSource = listSource

        TypeSensors.ObserveOnDispatcher.Subscribe(listSource)
    End Sub

    Private Sub QueryAny_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles QueryAny.Click
        Dim AnySensor = Sensor.Any(
            Function(s) s.SensorValue > 17)
        AnySensor.Subscribe(Sub(s) MessageBox.Show(s.ToString, "OutOfRange"))

    End Sub

    Private Sub Heartbeat_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles Heartbeat.Click
        Dim heartbeatAggregate = Sensor.
            BufferWithTime(TimeSpan.FromSeconds(3))
        
        heartbeatAggregate.Subscribe(
            Sub(val) Console.WriteLine(val.
                                       Where(Function(v) v.SensorType = "2").
                                       Count))

            'heartbeatAggregate.ObserveOnDispatcher.Subscribe(Sub(val) Heartbeat.Content = String.Format("{0} BPM", val * 20))

            'Dim producer = Observable.Interval(TimeSpan.FromMilliseconds(300))
            'Dim buffer = producer.BufferWithTime(TimeSpan.FromSeconds(1))
            'producer.Subscribe(Sub(value) Console.WriteLine(value))
            'buffer.Subscribe(Sub(values) Console.WriteLine("Sum: {0}", values.Sum))

    End Sub

    Private Sub MouseMoveSamples_Click(ByVal sender As System.Object, ByVal e As System.Windows.RoutedEventArgs) Handles MouseMoveSamples.Click
        Dim mouseSample = New MouseMoveSample
        mouseSample.Show()
    End Sub
End Class
